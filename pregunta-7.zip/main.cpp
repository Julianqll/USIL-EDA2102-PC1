#include <iostream>

using namespace std;

int main(){
  int oct=0,res=0,a=0,b=1;

  cout<<"Escriba el numero decimal"<<endl;
  cin>>a;

  while (a!=0){
    res=a%8;
    oct=res*b+oct;
    b=b*10;
    a=a/8;
  }

  cout<<"El numero en octal es "<<oct<<endl;
  
}